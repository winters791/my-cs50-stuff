#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    //prompt user for string
    string s1 = get_string("user1: ");
    string s2 = get_string("user2: ");
    int l1 = strlen(s1);
    int l2 = strlen(s2);
    //make array
    int c1[l1];
    int n = 0;
    for(int i = 0 ; i < l1 ; i++)
    {
       c1[n] = tolower(s1[n]);
       n++;
    }
    n = 0;
    int c2[l2];
    n = 0;
    for(int i = 0 ; i < l2 ; i++)
    {
       c2[n] = tolower(s2[n]);
       n++;
    }
    n = 0;
    int code[26] = {1,3,3,2,1,4,2,4,1,8,5,1,3,1,1,3,10,1,1,1,1,4,4,8,4,10};
    for(int i = 0 ; i < l1 ; i ++)
    {
        c1[n] = code[c1[n] - 97];
        if(c1[n] > 10)
        {
            c1[n] = 0;
        }
        n++;

    }

    n = 0;
    for(int i = 0 ; i < l2 ; i ++)
    {
        c2[n] = code[c2[n] - 97];
        if(c2[n] > 10)
        {
            c2[n] = 0;
        }
        n++;
    }
    n = 0;
    int score1 = 0;
    int score2 = 0;
    for(int i = 0 ; i < l1  ; i++)
    {
        score1 = score1 + c1[n];
        n++;
    }
    n = 0;
    for(int i = 0 ; i < l2  ; i++)
    {
        score2 = score2 + c2[n];
        n++;
    }
    if(score1 > score2)
    {
        printf("Player 1 wins!\n");
    }
    else if(score1 < score2)
    {
        printf("Player 2 wins!\n");
    }
    else
    {
        printf("Tie!\n");
    }




    //store values in array
    //make a program to compute array value
    //make program to compare the values of only alphabets
    //output results including a tie
}
