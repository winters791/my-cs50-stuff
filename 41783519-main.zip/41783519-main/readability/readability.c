#include <stdio.h>
#include <cs50.h>
#include <string.h>

int main(void)
{
    string o1 = get_string("input: ");
    int l1 = strlen(o1);

    int n = 0;
    int words = 1;
    for(int i = 0 ; i < l1 ; i++)
    {
    if(o1[n] == ' ')
    {
        n++;
        words++;
    }
    else
    {
        n++;
    }
    }
    n = 0;
    int letters = l1;
    for(int i =0;i<l1 ;i++)
    {
        if(o1[n] > 64 && o1[n] < 122 )
        {
            n++;;
        }
        else
        {
            letters--;
            n++;
        }
    }
    n = 0;
    int sentences = 0;

    for(int i = 0 ; i<l1 ; i++)
    {
        if(o1[n] == 63 || o1[n] == 46 || o1[n] == 33 )
        {
            sentences++;
            n++;
        }
        else
        {
            n++;
        }
    }
    int index = (5.88*letters - 29.6*sentences)/words - 15.8 + 1;
    if(index < 1)
    {
        printf("Before Grade 1\n");
    }
    else if(index > 16)
    {
        printf("Grade 16+\n");
    }
    else
{
    printf("Grade %i\n",index );
}


}





