#include <cs50.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, string argv[])
{
    int j = 0;
    for(int i = 0 ; i < strlen(argv[1]) ; i++)
 {
    argv[1][j] = toupper(argv[1][j]);
    j++;
 }
 if(argc != 2)
    {
        printf("Error1 \n");
        return 1;
    }
    else if(strlen(argv[1]) != 26)
    {
        printf("use 26 keys \n");
        return 1;
    }
    else
    {


    string text = get_string("Text: ");
    int l1 = strlen(text);
    int n = 0;
    int T[l1];
    for(int i = 0; i < l1 ; i++)
    {
        T[n] = text[n];
        n++;
    }
    n = 0;
    for (int i = 0 ; i < l1 ; i++)
    {
        if(T[n] >= 65 && T[n] <= 90)
        {
            text[n] = (argv[1][T[n] - 65]);
            n++;
        }
        else if(T[n] >= 97 && T[n] <= 122)
        {
            text[n] = tolower(argv[1][T[n] - 97]);
            n++;
        }
        else
        {
            n++;
        }

    }
      printf("ciphertext: %s\n" , text);
    }

}
