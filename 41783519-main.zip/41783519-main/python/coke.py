def coke():
    #input of coin
    x = input("coins: ")
    #reject non integer
    while True:
        if x.isnumeric():
            break
        else:
            x = input("coins: ")
    #substract the input from 50 and re iterate
    while True:
        if x > 50:
            key = 50 - x%50
            print(f"Change owed: {key}")
        if x < 50:
            key = x - 50
            print(f"Change Due: {key}")

    #show due amount
    #after 50 cents, show owed amount

coke()
