def main(name):
    y = convert(name)
    if 7 <= y <= 8:
        print("Breakfast time")
    elif 12 <= y <= 13:
        print("Lunch time")
    elif 18 <= y <= 19:
        print("Dinner time")
    else:
        print("unkown")



def convert(name):

        x , y = name.split(":")
        x = int(x)
        y = int(y)
        if x > 24:
            return 1
        y = y/60
        z = x + y
        return z


name = input("time: ")
if name.isnumeric():
    main(name)
if name.isnumeric() == False:
    convert(name)
    main(name)

