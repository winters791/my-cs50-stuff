x = input("input: ")
x , y , z = x.split(" ")
x = float(x)
z = float(z)
match y:
    case "+":
        print(x + z)
    case "*":
        print(x*z)
    case "-":
        print(x - z)
    case "/":
        print(x/z)


