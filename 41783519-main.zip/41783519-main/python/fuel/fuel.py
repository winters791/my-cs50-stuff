def main():
    x = get_int()
    percentagex = int(x * 100)
    print(f"{percentagex}%")

def get_int():
    while True:
        try:
            x = input("x: ")
            x = x.split('/')
            if x[1] == 0:
                print("Divison by zero not allowed")
            x = int(x[0])/int(x[1])
            if 0 < x < 0.01:
                print("E")
                break
            elif .99 < x < 1:
                print("F")
                break
            return x
        except ValueError:
            print("Please enter a valid number.")

main()

