x = int(input("input: "))
c = 3*pow(10,8)
csqr = pow(c,2)
e = x*csqr
print(e)
