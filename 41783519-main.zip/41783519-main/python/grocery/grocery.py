# grocery.py

grocery_list = {}

try:
    while True:
        # Prompt the user for input (case-insensitive)
        item = input().strip().lower()

        # Add or update item in grocery_list
        if item in grocery_list:
            grocery_list[item] += 1
        else:
            grocery_list[item] = 1

except EOFError:
    # Sort the grocery_list alphabetically and output the result
    for item in sorted(grocery_list):
        print(f"{grocery_list[item]} {item.upper()}")
