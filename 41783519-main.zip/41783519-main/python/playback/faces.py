x = input("Input: " )
x = x.replace(':)','🙂')
x = x.replace(':(','🙁')

print(x)
