x = input("Input: " )
x = x.replace(' ','...')
print(x)
