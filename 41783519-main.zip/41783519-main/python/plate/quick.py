x = input("input: ")
print(f"{len(x)}")
