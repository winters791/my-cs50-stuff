def main():
    plate = input("Plate: ")
    if is_valid(plate):
        print("Valid")
    else:
        print("Invalid")


def is_valid(s):
    #first two numbers should be Alphabets
    if len(s) > 6:
         return False
    if len(s) < 2:
         return False
    if s.isalpha():
         return True
    if s[0:1].isalpha():
        for _ in range(len(s)):
                if s[:_+1].isalpha() == False:
                    if s[_:].isdigit():
                        return True
                    else:
                         return False
    else:
            return False
    #if numbers start no more alphabets
    #not more than 6 char


main()
