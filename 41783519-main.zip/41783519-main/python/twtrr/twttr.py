#ask for string input
x = input("input: ")
result = " "
for i in range(len(x)):
    if x[i] not in 'aeiouAEIOU':
        result += x[i]
print(f"{result}")
#replace indexes with ""
#print result
