def coke():

    #input of coin
    x = input("Insert Coin: ")
    while True:
        if x.isnumeric():
            break
        else:
            x = input("Insert Coin: ")
    x = int(x)
    if x >= 50:
        amount_owed = int(x - 50)
        print(f"Amount owed: {amount_owed}")
    else:
        amount_due = int(50 - x)
        print(f"Amount Due: {amount_due}")
    while amount_due > 0:
        x = input("insert coin: ")
        x = int(x)
        if x > amount_due:
            amount_due = x - amount_due
            break
        if amount_due == 0:
            print("Change Owed: 0")
        else:
            amount_due = amount_due - x
            print(f"Change Due: {amount_due}")
    print(f"Change Owed: {amount_due}")


    #substract the input from 50 and re iterate
    #show due amount
    #after 50 cents, show owed amount

coke()
