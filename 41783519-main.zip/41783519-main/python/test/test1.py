x = input("input: ")
for _ in range(len(x)):
    print(f"{x[_]}")
