#find string fuction to remove/replace/find/whatever the first letter of sentence
x = input("how art thou: ")
x = x.lower().strip()
if x[0:5] == "hello":
    print("$0")
elif x[0] == "h" and x[0:5] != "hello":
    print("$20")
else:
    print("$100")
