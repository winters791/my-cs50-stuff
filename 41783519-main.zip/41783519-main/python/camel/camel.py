def camelcase():
    test = input("input: ")
    i = 0
    while i < len(test):
        if test[i].isupper():
            test = test[:i] + '_' + test[i].lower() + test[i+1:]
            i += 1  # Move past the new character we just added
        i += 1
    print(f"{test}")

camelcase()
