x = input("Input: ")
x = x.lower()
print(x)


#use def func to change the given input
