x = input("Whats the meaning of everything? ")
x = x.lower().strip()
if x == '42' or x == 'forty-two' or x== 'forty two':
    print("yes")
else:
    print("no")
