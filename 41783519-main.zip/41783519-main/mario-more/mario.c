#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <stdlib.h>

int main(void)
{
    string y = get_string("inputr: ");
    int y1 = atoi(y);
    printf("%i\n",y1);
}
